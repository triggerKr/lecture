package com.example.imap.config;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * 기존 설정의 문제
 *  - .anyRequest().permitAll() 때문에 /api/user/spawn 이 인증 없이 통과 ->
 *    @AuthenticationPrincipal UserDetails 가 null 로 주입되어 getUsername() 에서 NPE.
 *  - Nginx의 auth_request 에만 의존하므로 8083 에 직접 붙으면 인증 우회.
 *
 * 수정 방향: 기본 차단(anyRequest().authenticated()) 후 예외 경로만 개방.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // 인증 정보를 쿠키로 운반하므로 CSRF 노출면이 생긴다.
            // 아래 두 가지를 반드시 함께 둘 것:
            //   1) 쿠키에 SameSite=Strict (AuthController 참고)
            //   2) 상태 변경(POST/PUT/DELETE) API를 추가하면 CSRF 토큰 검증 도입
            // SameSite=Strict 만으로 버티는 동안의 임시 조치가 disable 이다.
            .csrf(csrf -> csrf.disable())

            // JWT 기반이므로 서버 세션을 만들지 않는다
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/login", "/api/auth/refresh").permitAll()
                .requestMatchers("/actuator/health").permitAll()
                // /api/auth/check 와 /api/user/** 를 포함한 나머지 전부 인증 필수
                .anyRequest().authenticated()
            )

            // 인증 실패 시 302 리다이렉트가 아니라 401 을 직접 응답해야
            // Nginx 의 error_page 401 -> @unauthorized 가 동작한다
            .exceptionHandling(handler -> handler
                .authenticationEntryPoint((request, response, authException) ->
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized"))
            )

            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
