package com.example.imap.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;

/**
 * 구조도에 Refresh Token 아이콘(Redis)은 있으나 재발급 경로가 없었다.
 * check / login / refresh 를 한 세트로 둔다.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final String ACCESS_TOKEN_COOKIE  = "IMAP_AT";
    private static final String REFRESH_TOKEN_COOKIE = "IMAP_RT";

    private final AuthService authService;   // JWT 발급 + Redis refresh 저장/조회

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * Nginx auth_request 전용. SecurityFilterChain 에서 authenticated() 이므로
     * 토큰이 없거나 만료면 필터 단계에서 401 이 나가고 여기까지 오지 않는다.
     */
    @GetMapping("/check")
    public ResponseEntity<Void> check(@AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok()
            .header("X-Auth-User", userDetails.getUsername())   // nginx auth_request_set 으로 회수 가능
            .build();
    }

    @PostMapping("/login")
    public ResponseEntity<Void> login(@RequestBody LoginRequest req) {
        var tokens = authService.authenticate(req.username(), req.password());
        authService.storeRefreshToken(req.username(), tokens.refreshToken());   // Redis

        return ResponseEntity.noContent()
            .header(HttpHeaders.SET_COOKIE, accessCookie(tokens.accessToken()).toString())
            .header(HttpHeaders.SET_COOKIE, refreshCookie(tokens.refreshToken()).toString())
            .build();
    }

    @PostMapping("/refresh")
    public ResponseEntity<Void> refresh(
            @CookieValue(name = REFRESH_TOKEN_COOKIE, required = false) String refreshToken) {

        if (refreshToken == null || !authService.isValidRefreshToken(refreshToken)) {
            return ResponseEntity.status(401).build();
        }

        var tokens = authService.rotate(refreshToken);   // 회전(rotation) 권장

        return ResponseEntity.noContent()
            .header(HttpHeaders.SET_COOKIE, accessCookie(tokens.accessToken()).toString())
            .header(HttpHeaders.SET_COOKIE, refreshCookie(tokens.refreshToken()).toString())
            .build();
    }

    // -----------------------------------------------------------------

    private ResponseCookie accessCookie(String token) {
        return ResponseCookie.from(ACCESS_TOKEN_COOKIE, token)
            .httpOnly(true)         // JS 접근 차단 (XSS 대비)
            .secure(false)          // HTTPS 도입 시 반드시 true
            .sameSite("Strict")     // csrf.disable() 을 버티게 해주는 유일한 방어선
            .path("/")
            .maxAge(Duration.ofMinutes(15))
            .build();
    }

    private ResponseCookie refreshCookie(String token) {
        return ResponseCookie.from(REFRESH_TOKEN_COOKIE, token)
            .httpOnly(true)
            .secure(false)
            .sameSite("Strict")
            .path("/api/auth/refresh")   // 재발급 요청에만 실려나가도록 경로 제한
            .maxAge(Duration.ofDays(7))
            .build();
    }

    public record LoginRequest(String username, String password) {}
}
