package com.example.imap.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;

/**
 * 핵심: 토큰을 "쿠키 우선, Authorization 헤더 폴백" 으로 읽는다.
 *
 * 이유 - 브라우저가 10.173.193.80/ 로 화면에 진입할 때 보내는 요청에는
 * Authorization 헤더가 없다. 헤더만 보면 Nginx auth_request 는 항상 401 이 되어
 * 사용자가 로그인해도 계속 /blank 로 튕긴다. 쿠키는 자동 전송되므로 이 문제가 없다.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    public static final String ACCESS_TOKEN_COOKIE = "IMAP_AT";

    private final JwtTokenProvider tokenProvider;      // 기존 검증 로직 주입
    private final UserDetailsService userDetailsService;

    public JwtAuthenticationFilter(JwtTokenProvider tokenProvider,
                                   UserDetailsService userDetailsService) {
        this.tokenProvider = tokenProvider;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        resolveToken(request)
            .filter(tokenProvider::validate)
            .ifPresent(token -> {
                String username = tokenProvider.getUsername(token);
                UserDetails user = userDetailsService.loadUserByUsername(username);

                UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                SecurityContextHolder.getContext().setAuthentication(authentication);
            });

        filterChain.doFilter(request, response);
    }

    /** 1순위: HttpOnly 쿠키 / 2순위: Authorization: Bearer (API 클라이언트용) */
    private Optional<String> resolveToken(HttpServletRequest request) {
        Optional<String> fromCookie = Optional.ofNullable(request.getCookies())
            .flatMap(cookies -> Arrays.stream(cookies)
                .filter(c -> ACCESS_TOKEN_COOKIE.equals(c.getName()))
                .map(Cookie::getValue)
                .findFirst());

        if (fromCookie.isPresent()) {
            return fromCookie;
        }

        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            return Optional.of(header.substring(7));
        }
        return Optional.empty();
    }
}
